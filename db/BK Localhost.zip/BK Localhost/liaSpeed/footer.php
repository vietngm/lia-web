		<?php get_template_part( 'template-parts/footer', "menu"); ?>
		<?php get_template_part( 'template-parts/footer', "nav"); ?>
		<?php wp_footer(); ?>
	</body>
</html>
